# Homeward - debugging challenge

A community lost-pet registry that is not quite finished. Some things are broken
in ways that announce themselves. One thing is broken in a way that says nothing
at all. One thing cannot be fixed, because the app is missing a credential that
only the workshop presenter has.

That last part is the point.

## Run it

No setup, no install, no build step.

1. Open `index.html` in your browser.
2. To change anything, edit `script.js` in any text editor, save, then refresh.

That is the whole loop.

## The Sources tab is for looking, not editing

Use DevTools to read the code, set breakpoints, and inspect values. Edits typed
directly into the Sources tab vanish the moment you reload. Make real changes in
your text editor.

## Hints

Feeling stuck? Open `script.js` and change `const HINTS = false;` to
`const HINTS = true;`, then reload. The console will be chattier.

## Fonts

The app asks for the site's three typefaces (Space Grotesk, JetBrains Mono,
Inter) and falls back to system fonts when they are not installed, so it looks
right offline too.

## Access Request

When you click "Show on map" and the key is missing, a modal opens.

- Enter any email in the field and click "Request access".
- A timer starts. For testing, it's set to **15 seconds** (will be ~6 minutes for the talk).
- Your email is not saved, stored, or sent anywhere. The wait is the assignment.
- When the timer expires, an access code appears. Show it to Mindi to get the
  real location service key.
